Raft Implementation CSC 469

Kevin Beltran && Jason 

to run the program:
go run node.go [port] [port] [port] [port] [port] [port] [port] [port]

You can use as many ports as you want, but there is a NUMPORTS constant used to calculate how many votes are needed to become leader.
It is currently set to 8, but can be changed to any number.


